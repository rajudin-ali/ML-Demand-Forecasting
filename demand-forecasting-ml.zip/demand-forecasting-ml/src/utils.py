import pandas as pd

def add_calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df['date'] = pd.to_datetime(df['date'])
    df['year'] = df['date'].dt.year
    df['month'] = df['date'].dt.month
    df['day'] = df['date'].dt.day
    df['dayofweek'] = df['date'].dt.dayofweek
    df['weekofyear'] = df['date'].dt.isocalendar().week.astype(int)
    return df

def add_lag_features(df: pd.DataFrame, target='demand', lags=(1,7,14,28)) -> pd.DataFrame:
    df = df.copy()
    for lag in lags:
        df[f'lag_{lag}'] = df[target].shift(lag)
    return df

def add_rolling_features(df: pd.DataFrame, target='demand', windows=(7,14,28)) -> pd.DataFrame:
    df = df.copy()
    for w in windows:
        df[f'rollmean_{w}'] = df[target].shift(1).rolling(w).mean()
        df[f'rollstd_{w}'] = df[target].shift(1).rolling(w).std()
    return df
