import argparse, json, os
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error
from sklearn.model_selection import TimeSeriesSplit
from xgboost import XGBRegressor
import joblib

from utils import add_calendar_features, add_lag_features, add_rolling_features

def make_features(df: pd.DataFrame) -> pd.DataFrame:
    df = add_calendar_features(df)
    df = add_lag_features(df, target='demand', lags=(1,7,14,28))
    df = add_rolling_features(df, target='demand', windows=(7,14,28))
    return df

def train_and_forecast(data_path: str, horizon: int, output_dir: str):
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs('reports', exist_ok=True)

    df = pd.read_csv(data_path)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date')

    df = make_features(df)

    feature_cols = [c for c in df.columns if c not in ['date', 'sku', 'demand']]
    df_model = df.dropna().reset_index(drop=True)

    X = df_model[feature_cols]
    y = df_model['demand']

    # Time-based split: last horizon*2 as test if available
    test_size = min(len(df_model)//5, max(horizon*2, 60))
    split_idx = len(df_model) - test_size
    X_train, y_train = X.iloc[:split_idx], y.iloc[:split_idx]
    X_test, y_test = X.iloc[split_idx:], y.iloc[split_idx:]

    model = XGBRegressor(
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        subsample=0.9,
        colsample_bytree=0.9,
        random_state=42
    )
    model.fit(X_train, y_train)

    pred_test = model.predict(X_test)
    mae = mean_absolute_error(y_test, pred_test)
    rmse = mean_squared_error(y_test, pred_test, squared=False)
    mape = (np.abs((y_test - pred_test) / np.clip(y_test, 1e-6, None))).mean() * 100

    print(f"Test MAE : {mae:.3f}")
    print(f"Test RMSE: {rmse:.3f}")
    print(f"Test MAPE: {mape:.2f}%")

    # Save model and feature info
    joblib.dump(model, os.path.join(output_dir, 'model_xgb.pkl'))
    with open(os.path.join(output_dir, 'feature_info.json'), 'w') as f:
        json.dump({'features': feature_cols}, f, indent=2)

    # Recursive forecasting horizon days ahead
    last_rows = df.tail(60).copy()
    future = []
    for h in range(1, horizon+1):
        next_date = last_rows['date'].iloc[-1] + pd.Timedelta(days=1)
        row = {
            'date': next_date,
            'sku': last_rows['sku'].iloc[-1] if 'sku' in last_rows.columns else None,
            'price': last_rows['price'].iloc[-1] if 'price' in last_rows.columns else None,
            'promo': 0
        }
        last_rows = pd.concat([last_rows, pd.DataFrame([row])], ignore_index=True)
        tmp = make_features(last_rows)
        feat_row = tmp.iloc[[-1]][feature_cols]
        yhat = float(model.predict(feat_row)[0])
        last_rows.loc[last_rows.index[-1], 'demand'] = max(0, yhat)
        future.append({'date': next_date.date().isoformat(), 'forecast': round(max(0, yhat), 2)})

    forecast_df = pd.DataFrame(future)
    forecast_df.to_csv('reports/forecast.csv', index=False)
    print("Saved:", 'reports/forecast.csv')

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument('--data', type=str, required=True, help='Path to CSV data')
    ap.add_argument('--horizon', type=int, default=30, help='Forecast horizon in days')
    ap.add_argument('--output_dir', type=str, default='models', help='Directory to save model')
    args = ap.parse_args()
    train_and_forecast(args.data, args.horizon, args.output_dir)
